package model;

public interface Descargable {

}
