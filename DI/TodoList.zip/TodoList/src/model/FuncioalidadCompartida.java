package model;

public interface FuncioalidadCompartida {
    public void metodoComun();
}
